package lexer;

/**
 *
 * @author super
 */
public interface Factor {
    ConjunctiveRepresentation conjunctiveRepresentation();
}
