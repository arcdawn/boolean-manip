added new tests too
