/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lexer;

import java.util.Optional;
import java.lang.Error;
/**
 *
 * @author super
 */
public class ParserException extends Exception{


    private static final long serialVersionUID = 293;
    public enum ErrorCode{
        TOKEN_EXPECTED("Token Expected"),
        INVALID_TOKEN("Invalid Token"),
        TRAILING_INPUT("Trailing Input");
        private final String error;
        private ErrorCode(String error){
            this.error = error;
        }
    }
    private static ErrorCode errorCode;
    private final int location;
    //constructor
    ParserException(LocationalToken token, ErrorCode errorCode){
        this.errorCode = errorCode;
        this.location = token.getLocation();
    }
    ParserException(ErrorCode errorCode){
        this.errorCode = errorCode;
        this.location = -1;
    }
    //return error 
    public ErrorCode getErrorCode(){
        return this.errorCode;
    }
    //return error location
    public int getLocation(){
        return this.location;
    }

    @Override
    public  String toString() {
        return "ParserException{" + "serialVersionUID=" + serialVersionUID + ", errorCode=" + errorCode + ", location=" + location + '}';
    }
    //if there is no expected token
    public static void verify(Optional<LocationalToken> token) throws Exception{
        if(!token.isPresent()){
            throw new Exception(ErrorCode.TOKEN_EXPECTED.error);
        }
    }
    //if there is a trailing input
    public static void verifyEnd(Optional<LocationalToken> token) throws Exception{
        if(token.isPresent()){
            throw new Exception(ErrorCode.TRAILING_INPUT.error);
        }
    }
    
}
