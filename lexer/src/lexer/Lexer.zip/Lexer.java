/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lexer;

import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lexer.ParserException.ErrorCode;
import static lexer.Token.Type;


/**
 *
 * @author super
 */
public class Lexer {
    private static Pattern tokenPatterns;
    private static boolean hasNextToken;
    private final Matcher matcher;
    
    
    public Lexer(String input){
        //token definition
        //compile these in one string
        String tokenz = "not | and | or | ( | ) | [a-z]+ | -?[0-9]+ | \\+|-|/|\\* | \\S+";
        tokenPatterns = Pattern.compile(tokenz);
        matcher = tokenPatterns.matcher(input);
        
        //format("| %s", string
    }
    //returns if there is a next token
    public Boolean hasNext(){
        return matcher.find();
    }
    //returns next LocationalToken
    public LocationalToken next() throws ParserException, Exception{
        if(hasNext()){
            for(Token.Type type: Token.Type.values()){
                if(matcher.group() == type.getStringPattern()){
                    Token locToken = Token.of(type, matcher.group());
                    return new LocationalToken(locToken, matcher.end());
                }
            }
           
        }
        throw new ParserException(ErrorCode.TOKEN_EXPECTED);
    }
    
    //Next valid token if applicable
    public Optional<LocationalToken> nextValid(Set<Token.Type> validTypes,
            Set<Token.Type> invalidTypes) throws ParserException, Exception{
        LocationalToken Token = next();
        if(validTypes.contains(Token.getType())){
            return Optional.of(Token);
        }
        if(invalidTypes.contains(Token.getType())){
            throw new ParserException(Token, ErrorCode.INVALID_TOKEN);
        }
        return Optional.empty();
    }
    
}
