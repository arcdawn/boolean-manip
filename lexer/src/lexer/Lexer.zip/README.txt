This submission includes the source files of the homework.
I haven't gotten the JUnit tests to work yet, will update if I can get it later.